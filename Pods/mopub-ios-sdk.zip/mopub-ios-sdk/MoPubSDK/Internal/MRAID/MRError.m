//
//  MRError.m
//
//  Copyright 2018-2021 Twitter, Inc.
//  Licensed under the MoPub SDK License Agreement
//  http://www.mopub.com/legal/sdk-license-agreement/
//

#import "MRError.h"

NSString * const MoPubMRAIDAdsSDKDomain = @"com.mopub.iossdk.mraid";
